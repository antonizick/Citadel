# Nx-Citadel

> **Claude Code directive:** After every major change (new feature, router edit, schema change, UI addition) and at the end of every session, update this file to reflect current project state. Keep it accurate — a future session will rely on it cold.

Self-hosted intelligence platform on Linux. Two main functions:
1. **Intelligence monitoring** — track topics/people/tech; periodic web search → AI summary → delivery
2. **IOC tracking** — pull threat-intel feeds, store indicators of compromise, run daily maintenance

Run: `python run.py` (port 8000, `0.0.0.0`, no reload) or via `citadel.service` (systemd). Venv at `.venv/`.
Start/stop helpers: `StartCitadel.sh` / `StopCitadel.sh`.
Default login on fresh install: **admin / admin** (seeded in `main.py:_seed_admin`).

---

## Stack

| Layer | Tech |
|---|---|
| API | FastAPI + uvicorn |
| Scheduler | APScheduler (cron + interval triggers) |
| LLM | Anthropic Claude API (`app/services/ai_service.py`) |
| Search | DuckDuckGo (default); Brave and SerpAPI fully implemented, selectable via `config.search.provider` |
| Output | Email (aiosmtplib/Gmail), Slack webhook, SMS (Twilio), Discord webhook |
| Templates | Jinja2 + vanilla JS + custom CSS (dark default; light theme togglable) |
| Auth | Session cookies (12 hr TTL), bcrypt passwords, TOTP MFA (`app/auth.py`) |

## Auth and roles

Three roles: **user**, **manager**, **admin**. Manager and admin must complete MFA setup on first login (enforced in `auth_router.py`). Admins can be flagged `mfa_exempt` to bypass this. MFA pending challenge expires after 5 minutes.

Auth middleware in `main.py` — bypass paths: `/login`, `/health`, `/static/*`, `/api/auth/*`.

Session management endpoints (`app/routers/auth_router.py`): login, MFA verify, logout, `/api/auth/me`, MFA setup/confirm/disable, change-password.

## Storage — no database

Everything is **markdown files with YAML frontmatter**. Never introduce a DB.

| Path | Contents |
|---|---|
| `data/interests/` | Watch topic definitions — UUID-named `.md` files |
| `data/reports/<interest-id>/` | Generated interest reports — timestamped `.md` files |
| `data/summary_reports/<report-id>/` | Summary report definitions + generated report files |
| `data/resources/` | Trusted resource monitor definitions — UUID-named `.md` files |
| `data/resource_reports/<resource-id>/` | Generated resource monitor reports — timestamped `.md` files |
| `data/iocs/` | IOC lists: `ips.md`, `domains.md`, `urls.md`, `hashes.md` |
| `data/users/` | User accounts |
| `data/config/settings.yaml` | All credentials/keys (SMTP, Anthropic, Twilio, Discord, search) |
| `data/config/ioc_sources.yaml` | IOC feed source definitions |
| `data/config/ioc_sync_status.yaml` | Last/next IOC sync timestamps + per-source results |

`app/storage/markdown_store.py` is the generic CRUD layer for all markdown stores.

### Report file frontmatter

Interest reports, summary reports, and resource reports all use the same frontmatter shape:

```yaml
---
interest_id: <uuid>   # or report_id / resource_id depending on type
name: <string>
generated_at: 2026-04-20T12:33:37.108621+00:00
---
```

All report-content API endpoints strip the frontmatter before sending markdown to the client, but parse and return `generated_at` as a separate JSON field so the UI can display it under the modal header.

## App structure

```
app/
  main.py           # FastAPI app, auth middleware, router registration, lifespan
                    # Static files served with ?v={startup-timestamp} for cache-busting
  auth.py           # Session management, bcrypt, TOTP; SESSION_TTL_HOURS=12, MFA_PENDING_TTL_MINUTES=5
  models.py         # Pydantic models — see model details section below
  config.py         # settings.yaml loader
  routers/
    auth_router.py      # /login page + /api/auth/* endpoints
    interests.py        # CRUD + run + reports + activity/recent + count-24h
    resources.py        # CRUD + run + reports; schedule_resource called on create/update/delete
    summary_reports.py  # CRUD + run + report files
    iocs.py             # IOC CRUD + counts + bulk CSV upload + maintenance trigger
    ioc_config.py       # IOC source config + manual pull trigger + sync status
    users.py            # User CRUD + MFA reset (admin-only)
    settings.py         # Settings CRUD + test endpoints (LLM, email, SMS, discord) + schedule list
    logs.py             # Read recent log lines + list archives
    admin.py            # Backup/restore, build-package, self-update (SSE), factory reset, terminate sessions
  services/
    ai_service.py         # summarize_results() for interests, summarize_resource() for resources
    search_service.py     # DuckDuckGo / Brave / SerpAPI (all three functional); search_multi(), search_web(), search_trusted_resource()
    summary_service.py    # run_summary_report() — collects interest reports → LLM synthesis → deliver
    scheduler_service.py  # run_interest(), run_resource(), schedule/unschedule for all three types; reload_all_schedules() covers interests + resources + summaries
    output_service.py     # deliver_outputs() / deliver_resource_outputs() / deliver_summary_outputs(); save/list/read for all three report types
    ioc_collector.py      # Pull threat feeds (Feodo Tracker, URLhaus, MalwareBazaar, OpenPhish; ThreatFox + OTX disabled)
    logger_service.py     # setup_logging() + log_user_action(); writes to logs/citadel.log with daily rotation
  storage/
    markdown_store.py     # Generic markdown CRUD
    ioc_store.py          # IOC-specific storage + dedup + maintenance (prune by expires_at / priority)
    user_store.py         # User CRUD
```

## Models

### Key model details (`app/models.py`)

**`DEFAULT_RESOURCE_PROMPT`** — module-level constant; the default prompt pre-loaded into new trusted resource monitors. Contains `[ SOURCE ]` as a substitution token. The full prompt instructs the AI to: never lead with a data coverage notice, extract stories from the past 48 hours, format each story as Title / Executive Summary / Technical Details / Known IOCs / Impact / Link, and append a "Data Coverage Notice" section at the bottom if needed. This constant is mirrored in `static/js/app.js` so the UI shows it immediately in the prompt textarea on new-resource forms.

**`ResourceOutputConfig`** — separate from `OutputConfig`; `types` defaults to `[]` (no delivery channels, reports always saved). `OutputConfig` (used by interests and summary reports) defaults to `types: ["report"]`.

**`Resource`** fields: `name`, `source` (URL or name — used as search query and `[ SOURCE ]` substitution), `type`, `prompt` (defaults to `DEFAULT_RESOURCE_PROMPT`), `tags`, `schedule` (default: `interval / 1 / days`), `output` (`ResourceOutputConfig`), `active`, `last_run`, `next_run`, `id`, `created_at`, `updated_at`.

## Scheduled jobs (registered at startup via `reload_all_schedules()`)

- `ioc_maintenance` — 02:00 UTC daily, prunes expired/low-priority IOC entries
- `ioc_collection` — 03:00 UTC daily, pulls all enabled feeds
- Per-interest report jobs — driven by each interest's `schedule` field
- Per-resource monitor jobs — driven by each resource's `schedule` field (default every 1 day)
- Per-summary-report jobs — driven by each summary report's `schedule` field

### Schedule config shape (interests, resources, and summary reports)

```yaml
schedule:
  type: interval          # interval | weekly | cron | manual
  interval_value: 1
  interval_unit: days     # minutes | hours | days | weeks
  run_time: "20:00"       # HH:MM UTC, used for weekly
  days_of_week: [0,1,2]   # 0=Mon … 6=Sun, used for weekly
  cron_expression: "0 20 * * *"   # used for cron type
```

APScheduler triggers are built in `_build_trigger()`. Intervals are anchored to `last_run` so jobs fire at the correct offset after a restart. `next_run` is written back into the config file after scheduling.

## Output config shape

Interests and summary reports use `OutputConfig` (`types` defaults to `["report"]`):
```yaml
output:
  types: [email, slack, sms, discord]   # "report" is implicit — always saved
  email_recipients: [user@example.com]
  slack_webhook: https://hooks.slack.com/...    # overrides default from settings.yaml
  sms_numbers: ["+15551234567"]
  discord_webhook: https://discord.com/api/webhooks/...
  report_format: markdown    # markdown | html
```

Resources use `ResourceOutputConfig` — identical shape but `types` defaults to `[]` (delivery off by default; reports always saved regardless).

## Resource monitor pipeline

When `run_resource(resource_id)` executes:
1. Loads resource from store; reads `source` and `prompt` fields
2. Renders prompt: `rendered_prompt = prompt.replace("[ SOURCE ]", source)`
3. Calls `search_multi(source, [], schedule)` — web search using source as query
4. Calls `summarize_resource(name, rendered_prompt, results)` — AI uses `rendered_prompt` as the user query / instruction
5. Calls `deliver_resource_outputs(resource, summary, output_sent)` — always saves `.md` to `data/resource_reports/<id>/`, optionally delivers to channels
6. Writes `last_run` back to resource store

The AI system prompt (`SYSTEM_PROMPT` in `ai_service.py`) is shared between interests and resources — it instructs the LLM to use only provided search results and cite every claim.

### Phase 2 (complete)
Interest runs call `get_recent_resource_reports()` (from `output_service.py`) to enrich summaries with pre-collected `.md` reports from `data/resource_reports/`. Filters by `max_age_days=7`, skips inactive resources, strips frontmatter, truncates each report to 4000 chars. The old `search_trusted_resource()` function still exists in `search_service.py` but is no longer called from `run_interest()`. Tag-based filtering is implemented in `get_recent_resource_reports()` but not yet wired to per-interest tags.

## IOC bulk upload (CSV)

`POST /api/iocs/{ioc_type}/bulk-upload` accepts a CSV. `GET /api/iocs/{ioc_type}/csv-template` returns the correct headers. Validation is strict: `status` must be `online`/`offline`; `priority_override` must be `low`/`medium`/`high`; dates must be `YYYY-MM-DD`; IPs must have a 2-letter country code and integer ASN; hashes require 32-char MD5 and 40-char SHA1. On conflict (same normalized value), sources and refs are merged; `conflict_resolution` param accepts `csv_wins` (default) or `form_wins`.

## Key design rules

- Markdown storage only — no SQL/NoSQL.
- Dark-theme UI default — CSS variables in `static/css/main.css`. Light theme toggled via `html.light-theme` class; overrides defined at the top of `main.css`. Preference persisted to `localStorage('citadel-theme')`. Toggle button sits next to Sign Out in the sidebar; login page has a fixed top-right icon button.
- Single-page app pattern — `templates/index.html` + `static/js/app.js` drive all UI; API-first routing.
- LLM model configured in `data/config/settings.yaml` under `llm.model` (currently `claude-sonnet-4-6`).

## Deploy / packaging

The admin panel has a **Build Package** button (`POST /api/admin/build-package`). This tars up the entire project (excluding `.venv/`, `__pycache__`, `data/`, `deploy/*.tar.gz`, etc.) into `deploy/nxcitadel-<timestamp>.tar.gz` with a `deploy/nxcitadel-latest.tar.gz` symlink. After building, **Download Package** pulls the archive. An integrity check (`_verify_package`) runs automatically; missing files are logged.

`data/` is intentionally excluded — user data stays on the server. Use **Full Backup** to export it separately.

### Self-update (SSE stream)

`GET /api/admin/self-update/stream?url=...` performs a 4-step live update streamed over SSE:
1. Full data backup
2. Code snapshot (build-package)
3. Download + extract new package (using `rsync` to preserve `data/`, `logs/`, `.venv/`)
4. `pip install -r requirements.txt` + `sudo systemctl restart nxcitadel` (falls back to manual restart if systemctl unavailable)

Default update URL: `https://www.antonizick.com/nxcitadel/nxcitadel-latest.tar.gz`

### Factory reset

`POST /api/admin/factory-reset/challenge` issues an 8-char code (10 min TTL).
`POST /api/admin/factory-reset/confirm` wipes **all** user-data directories:
`data/interests/`, `data/resources/`, `data/reports/`, `data/resource_reports/`,
`data/summary_reports/`, `data/iocs/`, `data/config/`, `data/users/`.
Also cancels all in-memory APScheduler jobs with IDs starting `interest_`, `resource_`, or `summary_` via `clear_user_schedules()` in `scheduler_service.py` — system jobs (`ioc_maintenance`, `ioc_collection`) are preserved.
After wiping, the default `admin / admin` account is immediately re-seeded (same as fresh install).
**Preserved:** `data/logs/` (application log archive), `logs/` root (live log file).

### Backup / restore

Full-backup (`GET /api/admin/backup/full`) ZIPs the entire `data/` directory — covers all of the above including `resource_reports/`, `summary_reports/`, IOC data, and IOC config files.
Full-restore (`POST /api/admin/restore/full`) validates the ZIP first, then does a clean wipe of all known data subdirectories before extracting — ensures no stale files survive the restore.
Granular ZIP backup/restore endpoints also exist for: settings only, interests, resources, reports, IOCs, users. All under `/api/admin/backup/*` and `/api/admin/restore/*`.
**Known gap:** `data/resource_reports/` is not included in any *granular* backup endpoint — only covered by the full-data backup.

## What's built

- Full CRUD UI for interests, resources, summary reports, IOCs, users, settings
- LLM setup wizard
- Scheduler: interval / weekly / cron / manual for all three monitor types (interests, resources, summary reports)
- Session auth + TOTP MFA (manager/admin enforced, admin-exempt flag)
- IOC feed ingestion (5 sources: Feodo Tracker, URLhaus, MalwareBazaar, OpenPhish; ThreatFox + OTX disabled)
- Bulk CSV IOC upload with strict validation
- Email / Slack / SMS / Discord output delivery
- Per-interest reports stored in `data/reports/`, viewable in UI with `generated_at` timestamp
- Executive summary reports stored in `data/summary_reports/`
- **Trusted resource monitors** — each resource runs on its own schedule, searches its `source`, AI-summarizes using a configurable `prompt` (default: detailed 48-hour story brief), stores reports in `data/resource_reports/`. UI shows tabbed modal (Basic/Schedule/Output), run button, reports viewer. Source field auto-substitutes `[ SOURCE ]` in the prompt textarea in real time as the user types.
- **Phase 2 resource integration** — interest runs enrich AI summaries with pre-collected trusted resource reports (read from `data/resource_reports/`, max 7 days old).
- User management (3 roles: user / manager / admin)
- Granular backup/restore (full, settings, interests, resources, reports, IOCs, users)
- Build-package / deploy workflow
- Self-update via SSE stream
- Factory reset with challenge code
- Log viewer (live tail + archive list)
- Settings test endpoints (LLM, email, SMS, Discord)
- `generated_at` timestamp displayed in report viewer modal (shared by interests, resources, and summary reports)
- Light/dark theme toggle (persisted to `localStorage`, no-flash via inline head script, WCAG AA contrast)
- **Output channel icons** on interests and summary reports list cards — four inline SVG icons (email/Slack/SMS/Discord) rendered via `outputIcons()` in `app.js`; bright brand colors when active, muted+28%-opacity when inactive, tooltip on hover. CSS: `.output-icons` / `.output-icon` in `main.css`.

## Dev mode

Set `system_state: dev` in `data/config/settings.yaml` (or via `POST /api/admin/system-state`) to suppress all **scheduled** runs for interests, resources, and summary reports. Manual runs (via the UI "Run" button) still fire. Useful during active development to prevent unintended LLM API calls. `GET /api/admin/system-state` returns the current value.

## Known gaps / not yet built

- `data/resource_reports/` not included in granular resource backup/restore endpoints (covered by full backup only).
- Resource tag filtering in `get_recent_resource_reports()` is implemented but not yet wired to per-interest tags (all active resources are always included in interest enrichment).
- No rate-limiting on any API endpoint.
- No HTTPS termination (run behind a reverse proxy in prod).
- ThreatFox and OTX IOC sources disabled pending API key support.
